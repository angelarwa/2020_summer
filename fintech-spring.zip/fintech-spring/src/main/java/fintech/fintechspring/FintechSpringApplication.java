package fintech.fintechspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FintechSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(FintechSpringApplication.class, args);
	}

}
